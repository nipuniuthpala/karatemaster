function fn() {
  return {};  
}
