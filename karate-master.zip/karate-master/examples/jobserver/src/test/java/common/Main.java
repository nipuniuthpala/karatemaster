package common;

/**
 *
 * @author pthomas3
 */
public class Main {
    
    public static void main(String[] args) {
        System.out.println("main ok");
    }
    
}
