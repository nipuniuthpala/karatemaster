package demo.graphql;

import demo.TestBase;

/**
 *
 * @author pthomas3
 */
public class GraphqlRunner extends TestBase {
    
}
