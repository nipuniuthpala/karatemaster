package demo.search;

import com.intuit.karate.KarateOptions;
import demo.TestBase;

/**
 *
 * @author pthomas3
 */
@KarateOptions(features = "classpath:demo/search/dynamic-params.feature")
public class SearchRunner extends TestBase {
    
}
