package demo.oauth;

import com.intuit.karate.KarateOptions;
import demo.TestBase;

@KarateOptions(features = "classpath:demo/oauth/oauth1.feature")
public class Oauth1Runner extends TestBase {


}
