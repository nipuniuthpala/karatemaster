package demo.callarray;

import com.intuit.karate.KarateOptions;
import demo.TestBase;

/**
 *
 * @author pthomas3
 */
@KarateOptions(features = "classpath:demo/callarray/call-json-array.feature")
public class CallJsonArrayRunner extends TestBase {
    
}
