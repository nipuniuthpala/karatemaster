package demo.upload;

import com.intuit.karate.KarateOptions;
import demo.TestBase;

/**
 *
 * @author pthomas3
 */
@KarateOptions(features = "classpath:demo/upload/upload-retry.feature")
public class UploadRetryRunner extends TestBase {
    
}
