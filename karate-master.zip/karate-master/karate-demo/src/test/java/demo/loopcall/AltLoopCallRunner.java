package demo.loopcall;

import com.intuit.karate.KarateOptions;
import demo.TestBase;

/**
 *
 * @author pthomas3
 */
@KarateOptions(features = "classpath:demo/loopcall/alt-loop.feature")
public class AltLoopCallRunner extends TestBase {
    
}
