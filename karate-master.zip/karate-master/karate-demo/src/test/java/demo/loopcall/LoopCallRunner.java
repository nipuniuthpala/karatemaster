package demo.loopcall;

import com.intuit.karate.KarateOptions;
import demo.TestBase;

/**
 *
 * @author pthomas3
 */
@KarateOptions(features = "classpath:demo/loopcall/loop.feature")
public class LoopCallRunner extends TestBase {
    
}
