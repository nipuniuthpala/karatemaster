package demo.cats;

import com.intuit.karate.KarateOptions;
import demo.TestBase;

/**
 *
 * @author pthomas3
 */
@KarateOptions(features = "classpath:demo/cats/cats.feature")
public class CatsRunner extends TestBase {
    
}
