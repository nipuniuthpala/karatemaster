package demo.cats;

import com.intuit.karate.KarateOptions;
import demo.TestBase;

/**
 *
 * @author pthomas3
 */
@KarateOptions(features = "classpath:demo/cats/cats-put.feature")
public class CatsPutRunner extends TestBase {
    
}
