package demo.headers;

import com.intuit.karate.KarateOptions;
import demo.TestBase;

/**
 *
 * @author pthomas3
 */
@KarateOptions(features = "classpath:demo/headers/null-header.feature")
public class NullHeaderRunner extends TestBase {
    
}
