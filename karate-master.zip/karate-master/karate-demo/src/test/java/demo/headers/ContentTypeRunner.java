package demo.headers;

import com.intuit.karate.KarateOptions;
import demo.TestBase;

/**
 *
 * @author pthomas3
 */
@KarateOptions(features = "classpath:demo/headers/content-type.feature")
public class ContentTypeRunner extends TestBase {
    
}
