package demo.soap;

import demo.TestBase;

/**
 *
 * @author pthomas3
 */
public class SoapRunner extends TestBase {
    
}
