package demo.websocket;

import com.intuit.karate.KarateOptions;
import demo.TestBase;

/**
 *
 * @author pthomas3
 */
@KarateOptions(features = "classpath:demo/websocket/websocket.feature")
public class WebSocketRunner extends TestBase {
    
}
