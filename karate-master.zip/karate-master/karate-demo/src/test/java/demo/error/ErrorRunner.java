package demo.error;

import com.intuit.karate.KarateOptions;
import demo.TestBase;

/**
 *
 * @author pthomas3
 */
@KarateOptions(features = "classpath:demo/error/error.feature")
public class ErrorRunner extends TestBase {
    
}
