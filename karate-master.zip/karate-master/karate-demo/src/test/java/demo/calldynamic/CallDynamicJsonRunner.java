package demo.calldynamic;

import com.intuit.karate.KarateOptions;
import demo.TestBase;

/**
 *
 * @author pthomas3
 */
@KarateOptions(features = "classpath:demo/calldynamic/call-dynamic-json.feature")
public class CallDynamicJsonRunner extends TestBase {
    
}
