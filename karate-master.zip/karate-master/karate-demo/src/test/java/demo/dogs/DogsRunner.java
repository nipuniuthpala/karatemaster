package demo.dogs;

import com.intuit.karate.KarateOptions;
import demo.TestBase;

/**
 *
 * @author pthomas3
 */
@KarateOptions(features = "classpath:demo/dogs/dogs.feature")
public class DogsRunner extends TestBase {
    
}
