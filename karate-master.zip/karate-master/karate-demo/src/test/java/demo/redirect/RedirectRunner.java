package demo.redirect;

import com.intuit.karate.KarateOptions;
import demo.TestBase;

/**
 *
 * @author pthomas3
 */
@KarateOptions(features = "classpath:demo/redirect/redirect.feature")
public class RedirectRunner extends TestBase {
    
}
