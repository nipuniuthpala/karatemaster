function fn(name) {
  karate.log('hello ' + name + '!');
}
