package demo.callfeature;

import com.intuit.karate.KarateOptions;
import demo.TestBase;

/**
 *
 * @author pthomas3
 */
@KarateOptions(features = "classpath:demo/callfeature/call-feature.feature")
public class CallFeatureRunner extends TestBase {
    
}
