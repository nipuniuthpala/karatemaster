package demo.binary;

import demo.TestBase;

/**
 *
 * @author pthomas3
 */
public class BinaryRunner extends TestBase {
    
}
