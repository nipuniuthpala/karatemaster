function fn() {
  return { confoverride: 'success' };
}