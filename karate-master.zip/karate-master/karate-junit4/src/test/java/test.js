function fn() {
  return 'hello world';
}
