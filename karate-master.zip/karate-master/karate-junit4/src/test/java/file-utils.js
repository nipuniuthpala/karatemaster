function fn(fileName) {
  var text = read(fileName);
  return text;
}
