function fn() {
  var temp = { confoverride: 'yes' };
  karate.log('temp:', temp);
  return temp;
}