function fn() {   
    return { baseconfig: 'loaded' };
}