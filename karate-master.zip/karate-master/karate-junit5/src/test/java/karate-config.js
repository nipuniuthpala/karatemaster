function fn(){ return {} }
