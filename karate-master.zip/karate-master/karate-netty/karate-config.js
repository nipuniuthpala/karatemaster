function fn() { return { mockServerUrl: 'http://localhost:8080/v1/' } }
