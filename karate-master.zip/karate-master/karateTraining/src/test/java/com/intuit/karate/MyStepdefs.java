package com.intuit.karate;

import cucumber.api.java.en.And;

public class MyStepdefs {
    @And("^match response==expectedResponse$")
    public void matchResponseExpectedResponse() {

    }
}
