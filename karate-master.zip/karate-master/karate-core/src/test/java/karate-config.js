function fn() {   
  return { someConfig: 'someValue' }
}